package net.mofed.reportracking.app.service;
/*
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import net.mofed.reportracking.app.model.Role;
import net.mofed.reportracking.app.model.User;
import net.mofed.reportracking.app.repository.RoleRepository;
@Component
public class RoleService {
	@Autowired 
	RoleRepository roleRepository;
	
	public Role findById(int id) {
		
		return roleRepository.findById(id);
	}

	

	public List<Role> findAll() {
		// TODO Auto-generated method stub
		return roleRepository.findAll();
	}


}
*/