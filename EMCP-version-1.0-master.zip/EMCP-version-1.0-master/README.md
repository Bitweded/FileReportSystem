# EMCP  SYSTEM


# Emcp  Project using Spring Boot + Spring MVC + Spring Security + JSP + Hibernate + MySQL

## Steps to follow

Account Login Credentials 

          Before attempting to login :- import the database included in the github repository !!
   
      1 .  Budget Manager
               
           username :  budget
           password :  123456

      2.  Audit Manager
          username :  Audit
           password :  123456

      3.  Cash Manager
          username :   cash
           password :  123456

      4.  Property Manager
          username:  property
          passoword:  123456

      5. Admin or EMCP
           
            username :  admin
           password :   admin

      6   Minister
           username :  minister
           password :  123456

      7.  SYSADMIN
          username :   superuser
           password :  123456
      8   USER(ORG USERS)

            username: org2@org2.com
            password:  123456

      8. Register an expert  or for any one of the directorates and u can be able to login to an expert homepage.


